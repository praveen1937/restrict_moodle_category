moodle-local_multiple_enrollments
==================================
A local plugin that allows admin to enrol multiple users into multiple courses.
It also allows to enrol/unenrol multiple courses to/from a user.

Version
-------
1.1.0 (2013032500)

Requires:
--------
Moodle 2.0 or higher

Installation:
------------
Download zip from: http://moodle.org/plugins/pluginversions.php?plugin=local_multiple_enrollments
Unzip into the 'local' subfolder of your Moodle install.
Rename the new folder to multiple_enrollments.
Visit http://yoursite.com/admin to finish the installation. 

Documentation:
-------------
Please feel free to contribute documentation in the relevant area of
the MoodleDocs wiki.

Release Notes
---------------
v1.1.1
ajax_assign_multiple_courses.php
An extra condition in the query to get only specific users to be displayed is got rid of