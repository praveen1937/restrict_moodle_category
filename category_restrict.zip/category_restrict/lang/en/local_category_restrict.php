<?php
$string['pluginname'] = 'Category Restriction';
$string['manage_groups'] = 'Manage Groups';
$string['category_restrict'] = 'Category Restriction';
?>